/** topics **/
const constants={
	DEBUG:true,

	DATABASE:'database/#',
	VALIDATE:'validate'
}

module.exports=constants