/** topics **/
const DEBUG=true;
const DATABASE ='database/#';

/** actions **/
module.exports={
	DATABASE:DATABASE,
	DEBUG:DEBUG
}