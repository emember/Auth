var config={}

config.mqttBroker='tcp://35.164.176.15:1883';

config.neo4jServer='http://172.31.0.71:443';
// config.neo4jServer='http://35.164.176.15:443';

config.neo4jKey='Authorization:Basic bmVvNGo6THliMzMwMDExIQ==';

module.exports=config